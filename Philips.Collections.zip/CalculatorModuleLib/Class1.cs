﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorModuleLib
{
    public class CalculatorViewModel:System.ComponentModel.INotifyPropertyChanged
    {
        #region DataMembers
        int operandOne, operandTwo,result;
        #endregion
        #region DataProperties
        public int OperandOne { get { return this.OperandOne; } set { this.operandOne = value; } }
        public int OperandTwo { get { return this.operandTwo; } set { this.operandTwo = value; } }
        public int Result {
            get { return this.result; }
            set {
                if (value != this.result)
                {
                    this.result = value;
                    OnPropoertyChanged("Result");
                }
            } }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Behaviors
           void OnPropoertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
                
        }
        #endregion
        #region ViewLogic
        public void Add()
        {
            //this.result = operandOne + operandTwo;
            this.Result = OperandOne + OperandTwo;
           
        }
        #endregion
    }
}
