﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModelsLib
{
    public class DiagnosticReport
    {
        public string ReportId { get; set; }
        public string ReportDescription { get; set; }
        public string ReportStatus { get; set; }
        public string MRN { get; set; }
        public string DeptCode { get; set; }
    }
}
