﻿using LoggerContractLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.Collections.Tests
{
    class FakeLoggerStub : ILogger
    {
        public void Write(string msg)
        {
        
        }
    }
}
