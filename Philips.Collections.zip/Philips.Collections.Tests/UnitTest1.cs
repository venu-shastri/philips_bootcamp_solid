﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Philips.Collections.Tests
{
    [TestClass]
    public class ArralistTests
    {
        [TestMethod]
        public void Given_ArrayList_When_AddItem_Invoked_Then_Valid_Count_Expected()
        {
            Philips.Collections.ArrayList arrayList = new ArrayList();
            arrayList.LoggerRef = new FakeLoggerStub();
            arrayList.CrankEngineRef = new Moq.Mock<CipherAlgorithmContractLib.IEncryptAndDecrypt>().Object;
            arrayList.AddItem(1);
            arrayList.AddItem(1);

            Assert.AreEqual(2, arrayList.Count);

        }
        [TestMethod]
        public void Given_ArrayList_When_AddItem_Invoked_Then_Expected_To_Call_EncryptMethod_Once()
        {
            Moq.Mock<CipherAlgorithmContractLib.IEncryptAndDecrypt> _mockObj =
                new Moq.Mock<CipherAlgorithmContractLib.IEncryptAndDecrypt>();

            
            Philips.Collections.ArrayList arrayList = new ArrayList();
            //Set Dependency 
            CipherAlgorithmContractLib.IEncryptAndDecrypt neighbourRef = _mockObj.Object;


            arrayList.CrankEngineRef = neighbourRef;
            arrayList.LoggerRef = new FakeLoggerStub();
            //Behavior
            arrayList.AddItem("content");
            //Expected Behhavior


            _mockObj.Verify(neighbour => neighbour.Encrypt("content"),Moq.Times.Exactly(3));
            

        }
    }
}
