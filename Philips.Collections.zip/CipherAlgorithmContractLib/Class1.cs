﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CipherAlgorithmContractLib
{
    public interface IEncryptAndDecrypt
    {
        object Encrypt(object content);
        object Decrypt(object cipher);

    }
}
