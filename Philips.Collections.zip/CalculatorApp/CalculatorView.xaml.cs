﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CalculatorApp
{
    /// <summary>
    /// Interaction logic for CalculatorView.xaml
    /// </summary>
    public partial class CalculatorView : Window
    {
        //CalculatorModuleLib.CalculatorViewModel _vmRef = new CalculatorModuleLib.CalculatorViewModel();
        public CalculatorView()
        {
            InitializeComponent();
          //  this.DataContext = _vmRef;
            //this.addButton.Command = _vmRef.AddCommand;


            // <TextBox Text="{Binding Source=_vmRef,Path=Result,Mode=OneWay}"/>

            //Binding

            //Binding _connector_result = new Binding();
            ////source Object
            //_connector_result.Source = _vmRef;
            ////Source Property
            //_connector_result.Path = new PropertyPath("Result");
            ////Mode
            //_connector_result.Mode = BindingMode.OneWay;
            ////Set Target Property
            //this.resultTextBox.SetBinding(TextBox.TextProperty, _connector_result);




            



        }
    }
}
