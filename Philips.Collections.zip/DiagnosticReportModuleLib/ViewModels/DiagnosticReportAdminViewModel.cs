﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DiagnosticReportModuleLib.ViewModels
{
    public class DiagnosticReportAdminViewModel
    {
        #region Initializers
        public DiagnosticReportAdminViewModel()
        {
            this.AddNewReportCommand = new MVVMUtilityLib.DelegateCommand(
                (object obj) => { AddNewDiagnosticReport(); },
                (object obj) => { return true; });
        }
        #endregion

        #region Private Feilds
        DataModelsLib.DiagnosticReport _reportRef = new DataModelsLib.DiagnosticReport();
        List<DataModelsLib.DiagnosticReport> _reportList = new List<DataModelsLib.DiagnosticReport>();
        #endregion

        #region Properties
        public string ReportId
        {
            get { return this._reportRef.ReportId; }
            set { this._reportRef.ReportId = value; }
        }
        public string MRN
        {
            get { return this._reportRef.MRN; }
            set { this._reportRef.MRN = value; }
        }

        public string DeptCode
        {
            get { return this._reportRef.DeptCode; }
            set { this._reportRef.DeptCode = value; }
        }

        public string ReportDescription
        {
            get { return this._reportRef.ReportDescription; }
            set { this._reportRef.ReportDescription = value; }
        }

        public string ReportStatus
        {
            get { return this._reportRef.ReportStatus; }
            set { this._reportRef.ReportStatus = value; }
        }

        #endregion

        #region Commands
        public ICommand AddNewReportCommand { get; set; }
        #endregion

        #region ViewLogic

        public void AddNewDiagnosticReport()
        {
            _reportList.Add(this._reportRef);
        }
        #endregion
    }
}
