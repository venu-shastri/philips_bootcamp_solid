﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.Collections
{
    public class ArrayList
    {
        private LoggerContractLib.ILogger loggerRef;
        private CipherAlgorithmContractLib.IEncryptAndDecrypt crankEngineRef;
        private object[] items;
        private int index = -1;
        private int count = 0;
        public ArrayList()
        {
            items = new Object[10];
        }
        public void AddItem(object item)
        {
            count++;
            this.loggerRef.Write("Add Item Called");
            index++;
            if (index >= items.Length)
            {
                //resize
                object[] temp = new object[items.Length + 10];
                items.CopyTo(temp, 0);
                items = temp;
            }
            items[index] =  this.crankEngineRef.Encrypt(item)
                ;
        }
        public void Clear()

        {
            this.loggerRef.Write("Items Cleared");

            //this.items = new object[10];
            for(int i = 0; i < items.Length; i++)
            {
                items[i] = null;
            }
            index = -1;
        }
        public int Count { get { return this.count; } }

        public LoggerContractLib.ILogger LoggerRef
        {
            get { return this.loggerRef; }
            set { this.loggerRef = value; }
        }

        public CipherAlgorithmContractLib.IEncryptAndDecrypt CrankEngineRef
        {
            get
            {
                return this.crankEngineRef;
            }
            set
            {
                this.crankEngineRef = value;
            }
        }
        


        
    }
}

