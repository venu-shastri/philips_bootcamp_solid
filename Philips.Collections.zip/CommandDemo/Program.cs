﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandDemo
{
    public class DelegateCommand : System.Windows.Input.ICommand
    {
        public event EventHandler CanExecuteChanged;

        private Action<object> _executeMethodAddress;
        private Func<object, bool> _canExecuteMethodAddress;

        public DelegateCommand(Action<object> executeMethodAddress,Func<object,bool> canExecuteMethodAddress)
        {
            this._executeMethodAddress = executeMethodAddress;
            this._canExecuteMethodAddress = canExecuteMethodAddress;
        }


        public bool CanExecute(object parameter)
        {
            return this._canExecuteMethodAddress.Invoke(parameter); 
        }

        public void Execute(object parameter)
        {
            this._executeMethodAddress.Invoke(parameter);
        }
    }
    public class ViewModel
    {
        #region Initializers
        public ViewModel()
        {
            //Action<object> executefunObj = new Action<object>(this.onSaveCommandExecute);
            //Action<object> executefunObj = (object obj) => { this.Save(); };
            //Func<object, bool> canExecuteFunObj = new Func<object, bool>(this.OnSaveCommandCanExecute);
            //Func<object, bool> canExecuteFunObj = (object obj) => { return true; };
            //SaveCommand = new DelegateCommand(executefunObj, canExecuteFunObj);

            SaveCommand=new  DelegateCommand(
                (object obj) =>{ this.Save(); },
                (object obj) => { return true; }
                );

        }
        #endregion
        #region Commands
        public System.Windows.Input.ICommand SaveCommand { get; set; }
        #endregion
        //#region CommandHelpers/ViewLogicCommandWrapers
        // void onSaveCommandExecute(object parameter)
        //{
        //    this.Save();
        //}
        //bool OnSaveCommandCanExecute(object parameter)
        //{
        //    return true;
            
        //}
        //#endregion
        #region ViewLogic
        public void Save() { }
        #endregion
    }
    public class View
    {
        ViewModel _viewModelRef = new ViewModel();
        public void Button_Click()
        {
            if (this._viewModelRef.SaveCommand.CanExecute(null))
            {
                this._viewModelRef.SaveCommand.Execute(null);

            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
